# Atlassian-style Design System — Teal

A design system built on the structure and conventions of the **Atlassian Design System**
(the token naming, the two-tier primitive/semantic model, the 4px spacing scale, the
component set) with the brand color swapped out for a custom teal, **`#599BAE`**.

## What this is

This system follows Atlassian's approach closely:

- **Two-tier color tokens.** Raw primitives (`teal-500`, `neutral-800`, …) are never used
  directly in product UI. Semantic tokens (`color-background-brand-bold`,
  `color-text-danger`, …) alias a primitive and describe *what the color is for*, not what
  it looks like. When the brand shifts, only the primitive scale changes — every semantic
  token, component and product surface updates automatically.
- **Light and dark themes**, defined together so every semantic token resolves correctly
  in both.
- **An 8-step spacing scale** on a 4px base (`space-025` through `space-800`), the same
  rhythm Atlassian uses for padding, gaps and page-level spacing.
- **Type scale** built from a heading, body, UI-label and code group — matched to
  Atlassian's Heading/Body/Code structure, set in **SF Pro** via the system font stack
  (`-apple-system` / `BlinkMacSystemFont` resolve to SF Pro on macOS and iOS; other
  platforms fall back to their native UI font — Segoe UI on Windows, Roboto on
  Android/Chrome OS — since SF Pro's font files are Apple-licensed and can't be bundled
  here).

## Brand color

The primary brand color is **`#599BAE`** — a muted, desaturated teal — used as
`teal-500` in the primitive scale and referenced by every "brand" semantic token
(primary buttons, links, focus rings, selected states). It replaces Atlassian's
signature blue (`#0052CC`) one-for-one in the token structure, so any UI already wired
to semantic tokens (rather than hard-coded hex) re-skins with no code changes.

| Step | Hex | Typical use |
|---|---|---|
| teal-50 | `#EEF6F8` | Selected-row / subtle brand background |
| teal-500 | **`#599BAE`** | Primary buttons, links, brand accents |
| teal-600 | `#487E8C` | Primary button hover |
| teal-700 | `#386271` | Primary button pressed, link text |
| teal-900 | `#1A2E36` | Brand-subtlest background in dark mode |

## Accessibility

- Body text tokens (`color-text` on `color-background`) are checked for **4.5:1** contrast
  in both themes.
- `color-text-brand` and `color-link` use `teal-700` (light) / `teal-300` (dark) rather
  than the brighter `teal-500`, specifically because `teal-500` text on white falls short
  of 4.5:1 — `teal-500` is reserved for large-scale fills (buttons, bold surfaces), where
  the 3:1 non-text threshold applies.
- `color-border-focus` is teal at 3:1+ against its surroundings in both themes; apply it
  as a 2px outline offset 2px from the control, never as the only differentiator between
  states.

## Components in this system

- **Button** — primary, secondary and danger variants, each with default/hover/pressed/disabled.
- **Lozenge** — the small status pill Atlassian uses across Jira/Confluence (Success, Removed, In progress, New, Default).
- **Tag** — removable, rounded labels for filters and metadata.
- **Banner** — full-width page-level messages (info, warning, danger, success).
- **Card** — a padded, bordered surface with a header slot, the base for panels and list items.

## Using the tokens

Every token below compiles to a CSS custom property of the same name
(`space-100` → `var(--space-100)`, `color-background-brand-bold` →
`var(--color-background-brand-bold)`). Always reach for the semantic token; drop to a
primitive only when building a new semantic token itself.
