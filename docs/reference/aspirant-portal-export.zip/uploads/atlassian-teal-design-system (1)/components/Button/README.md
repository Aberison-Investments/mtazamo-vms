A pressable action, in three emphasis levels plus a disabled state.

## Variants

- **Primary** (`color-background-brand-bold`) — one per view, for the single most
  important action.
- **Secondary** (`color-background-neutral`) — the default choice for most actions.
- **Danger** (`color-background-danger-bold`) — destructive actions (delete, remove).
  Pair with a confirmation step for anything irreversible.
- **Disabled** (`color-background-disabled` / `color-text-disabled`) — never the only
  way to explain why an action is unavailable; add helper text nearby.

## Tokens used

`color-background-brand-bold`, `color-background-brand-bold-hovered`,
`color-background-neutral`, `color-background-neutral-hovered`,
`color-background-danger-bold`, `color-background-disabled`,
`color-text-inverse`, `color-text`, `color-text-disabled`,
`color-border-focus`, `radius-100`, `space-100`, `space-150`, `ui-text`.

## Guidelines

- Keep labels to one or two words, verb-first ("Create issue", not "Issue creation").
- Only one primary button per screen or panel; a screen with two competing primaries
  has no clear default action.
- The 2px focus ring (`color-border-focus`) must never be suppressed — it's the only
  keyboard-navigation cue on a filled button.
