A removable, rounded label for filters, keywords and metadata a person attaches
themselves — distinct from Lozenge, which shows a status the system assigns.

## Tokens used

`color-background-neutral`, `color-background-neutral-hovered`,
`color-background-brand-subtlest`, `color-text`, `color-text-subtle`,
`color-text-brand`, `radius-050`.

## Guidelines

- Tags are user-generated (labels, filters); Lozenges are system-generated
  (status). Don't use one for the other's job.
- Always give the remove control an accessible label ("Remove <tag name>").
- Wrap tags onto multiple lines rather than truncating or scrolling.
