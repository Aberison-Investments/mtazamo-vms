A small status pill for a single word or short phrase — the workhorse of status
columns in issue and task lists.

## Variants

Default, Brand, Success, Warning, Danger — each pairs a `-subtlest` background with
its matching `-text`/`-brand` foreground, so the pill stays legible without competing
with bolder UI like buttons.

## Tokens used

`color-background-neutral`, `color-background-brand-subtlest`,
`color-background-success-subtlest`, `color-background-warning-subtlest`,
`color-background-danger-subtlest`, `color-text-subtle`, `color-text-brand`,
`color-text-success`, `color-text-warning`, `color-text-danger`, `radius-050`.

## Guidelines

- One lozenge per item — stacking several turns a status column into noise.
- Keep the label to one or two words; a lozenge is a label, not a sentence.
- Don't rely on color alone: the label text itself must say what the status is.
