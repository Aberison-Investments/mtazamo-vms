A padded, bordered surface — the base for panels, list items and preview tiles
across the product.

## Tokens used

`color-background`, `color-background-subtle`, `color-border`, `radius-100`,
`shadow-raised`, `space-200`, `heading-medium`, `body`.

## Guidelines

- Use `shadow-raised` only on `color-background`, never stacked on another
  shadowed surface.
- Keep card padding at `space-200`; don't tighten it to fit more content — trim
  the content instead.
- A card's title should stand on its own if the card is the only thing visible
  (search results, a shared link preview).
