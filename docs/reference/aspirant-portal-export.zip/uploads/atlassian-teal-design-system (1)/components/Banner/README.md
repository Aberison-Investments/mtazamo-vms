A full-width message at the top of a page or panel, for information that affects
the whole view rather than one field or row.

## Variants

Info (brand), Warning, Danger, Success — each built from a `-subtlest` background,
matching `-bold` dot and matching text token.

## Tokens used

`color-background-brand-subtlest`, `color-background-warning-subtlest`,
`color-background-danger-subtlest`, `color-background-success-subtlest`,
`color-background-brand-bold`, `color-background-warning-bold`,
`color-background-danger-bold`, `color-background-success-bold`,
`color-text-brand`, `color-text-warning`, `color-text-danger`, `color-text-success`,
`radius-100`.

## Guidelines

- One banner per concern; stack them only when genuinely unrelated (a stale-data
  notice and a failed deploy are both true at once, for example).
- Danger banners for something that already went wrong; Warning for something that
  will go wrong if unaddressed.
- Keep copy to one sentence with a clear next step where one exists.
